﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Models; // Adjust this using directive as needed
using System; // Ensure this is added for DateTime access

namespace WebApplication2.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<ProjectTask> Tasks { get; set; } // Ensure this matches your model class name

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProjectTask>().HasData(
                new ProjectTask { Id = 1, Title = "Sample Task 1", Description = "This is a sample task description.", DueDate = DateTime.Now.AddDays(10), IsCompleted = false },
                new ProjectTask { Id = 2, Title = "Sample Task 2", Description = "This is another sample task description.", DueDate = DateTime.Now.AddDays(20), IsCompleted = false }
            );
        }
    }
}
