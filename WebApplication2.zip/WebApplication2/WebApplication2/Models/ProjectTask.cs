﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models // Replace with your actual namespace
{
    public class ProjectTask // Renamed from 'Task' to 'ProjectTask' to avoid conflict
    {

        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DueDate { get; set; }
        public bool IsCompleted { get; set; }
    }
}
